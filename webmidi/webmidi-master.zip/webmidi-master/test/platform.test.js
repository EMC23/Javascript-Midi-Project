describe("Platform", function() {

  // We need to check for platforms that do not support the Web MIDI API nor the JazzPlugin (such
  // as Firefox 52+).
  it("should be checked to make sure current environment is supported.", done => done());

});
